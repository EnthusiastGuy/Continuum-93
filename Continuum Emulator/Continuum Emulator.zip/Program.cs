﻿using System;

namespace Continuum_Emulator
{
    public static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            new Continuum(args).Run();
        }
    }
}
