// Ed Davis. Tiny Basic that can play Star Trek
// Supports: end, list, load, new, run, save
// gosub/return, goto, if, input, print, multi-statement lines (:)
// a single numeric array: @(n), and rnd(n)

/*
 * TinyBasic Interpreter in C#
 * 
 * This TinyBasic interpreter is a simple, line-oriented interpreter for a subset of the BASIC programming language. 
 * Implemented in C#, the interpreter reads user commands or lines of a TinyBasic program, processes them, and executes 
 * them according to the rules of the TinyBasic language. This comment provides a step-by-step overview of the interpreter's 
 * functionality to help understand how the system works as a whole.
 * 
 * Step-by-Step Overview:
 * 
 * 1. Initialization and Input Handling:
 *    - The interpreter begins in an infinite loop, prompting the user for input.
 *    - The user can enter direct commands or lines of a TinyBasic program.
 *    - Input is stored in the `pgm[0]` array, and the lexer (`initlex(0)`) processes this input, tokenizing it into meaningful components.
 * 
 * 2. Command Processing:
 *    - The interpreter determines the type of command or statement entered.
 *    - Common commands include `RUN`, `LIST`, `NEW`, `SAVE`, `LOAD`, and `GOTO`, each with specific handlers.
 *    - Depending on the command, the interpreter may start executing the program, list the program, clear the memory, save or load a file, or jump to a specific line number.
 * 
 * 3. Program Storage and Execution:
 *    - Program lines are stored in the `pgm[]` array, with line numbers as indices.
 *    - Variables are stored in the `vars[]` array, and loop management data is stored in arrays such as `forvar[]`, `forlimit[]`, `forline[]`, and `forpos[]`.
 *    - The interpreter executes the program sequentially or jumps between lines based on commands like `GOTO` or `GOSUB`.
 *    - Expressions are evaluated using the `expression()` function, which handles operator precedence and parentheses.
 * 
 * 4. Error Handling and Debugging:
 *    - Functions like `expect()` and `validlinenum()` ensure syntax correctness, flagging errors when expected tokens or valid line numbers are not found.
 *    - If tracing is enabled, detailed information about each step is output, aiding in debugging.
 * 
 * 5. Subroutine and Loop Management:
 *    - The interpreter manages subroutines using `GOSUB` and `RETURN`, storing the current state on stacks to return after the subroutine completes.
 *    - `FOR` loops are managed by storing loop state data, allowing iterative execution until the loop condition is no longer met.
 * 
 * 6. File Operations:
 *    - The `SAVE` command writes the program to a file, ensuring it can be reloaded later.
 *    - The `LOAD` command reads a program from a file, restoring it to memory.
 * 
 * 7. Program Termination:
 *    - Commands like `QUIT` or `BYE` exit the interpreter, ending the session.
 * 
 * Conclusion:
 * - This TinyBasic interpreter provides a simple environment for creating, saving, loading, and running TinyBasic programs. 
 *   It handles basic programming constructs like loops, conditionals, and subroutines, processing input line by line, tokenizing, 
 *   parsing, and executing commands or program lines sequentially. The interpreter is designed for simplicity and clarity, making 
 *   it easy to understand and extend.
 */
/*
class Program {

  const int c_maxlines = 7000, c_maxvars = 26, c_at_max = 1000;   // maximum number of lines, maximum number of variables and the maximum size of the @ array.

  static string[] pgm = new string[c_maxlines + 1]; // program stored here
  static int[] vars = new int[c_maxvars + 1];       // variable store
  static int[] atarry = new int[c_at_max];          // the @ array

  static Stack<int> gstackln = new Stack<int>();    // gosub stack for the line number where gosub was called
  static Stack<int> gstacktp = new Stack<int>();    // gosub stack for the position on the line where gosub was called

  // Array to store the current value of each loop variable in active `FOR` loops.
  // Each entry corresponds to a loop variable, with the index mapping directly to the variable (e.g., index 0 for variable `A`, index 1 for `B`, etc.).
  static int[] forvar = new int[c_maxvars];

  // Array to store the limit value for each loop variable in active `FOR` loops.
  // This array holds the value that each loop variable is compared against to determine whether the loop should continue or terminate.
  static int[] forlimit = new int[c_maxvars];

  // Array to store the starting line number for each `FOR` loop.
  // This array keeps track of where each `FOR` loop begins, allowing the interpreter to jump back to the start of the loop when executing the `NEXT` statement.
  static int[] forline = new int[c_maxvars];

  // Array to store the position within the line (text pointer) where each `FOR` loop starts.
  // This array helps the interpreter correctly resume execution from the exact position within the line where the `FOR` loop starts, especially when multiple statements are on the same line.
  static int[] forpos = new int[c_maxvars];

  static string tok, toktype;                       // current token, and it's type
  static string thelin, thech;                      // current program line, current character
  static int curline, textp;                        // position in current line
  static int num;                                   // last number read by scanner
  static bool errors;
  static bool tracing;

  static TimeSpan timestart;
  static Random random = new Random();


  /// <summary>
  /// The entry point of the TinyBasic interpreter.
  /// 
  /// This method sets up the environment for the interpreter and initiates the main Read-Eval-Print Loop (REPL),
  /// which continually waits for user input, processes it, and executes commands or stores program lines.
  /// 
  /// Key functionalities include:
  /// - Initialization: Resets the interpreter's state with `newstmt()`.
  /// - Help Display: Calls `help()` to display available commands and their usage.
  /// - User Input Loop:
  ///   - Prompts the user with "c#> " to input a command or a program line.
  ///   - If the input is a line number (e.g., "10 PRINT 'HELLO'"), it stores the line in the program memory.
  ///   - If the input is a command (e.g., "RUN"), it executes the command immediately.
  /// - Command Execution: Determines if the input is a line number or a command and processes it accordingly.
  /// - Error Handling: Flags and manages errors during the parsing and execution of commands or statements.
  /// 
  /// The loop continues indefinitely, allowing the user to interactively input and execute TinyBasic programs,
  /// until an exit command such as "bye" or "quit" is given, which terminates the interpreter.
  /// </summary>
  /// <param name="args">Command-line arguments (not used in this implementation).</param>
  static void Main(string[] args) {
    newstmt();                                    // Initialize the interpreter state, clearing any previous program.
    help();                                       // Display the help information for the user.
    while (true) {
      errors = false;                             // Reset the error flag before each user interaction.
      Console.Write("c#> ");                      // Prompt the user for input.
      pgm[0] = Console.ReadLine();                // Read the user's input.

      if (pgm[0] != "") {                         // Proceed only if the input is not empty.
        initlex(0);                               // Initialize the lexer to parse the input.
        if (toktype == "number") {                // Check if the input starts with a line number.
          validlinenum();                         // Validate the line number.
          pgm[num] = pgm[0].Substring(textp - 1); // Store the line in the program memory.
        } else {
          docmd();                                // If not a line number, treat it as a command and execute it.
        }
      }
    }
  }

  /// <summary>
  /// Executes a command or statement within the TinyBasic interpreter.
  /// 
  /// The `docmd` function is the core of the TinyBasic command execution process. It processes the
  /// current token (`tok`) and determines the appropriate action to take, such as executing a control statement,
  /// performing input/output, or managing program flow. This function is invoked whenever a command is identified,
  /// and it handles all the main operations that can be performed by the interpreter.
  ///
  /// Key functionalities include:
  /// - Identifying the command or statement type by examining the current token (`tok`).
  /// - Executing the corresponding action for commands such as `RUN`, `PRINT`, `GOSUB`, `IF`, and more.
  /// - Handling special commands like `GOTO`, `FOR`, `NEXT`, which affect program flow and control structures.
  /// - Managing program tracing if `tron` (trace on) or `troff` (trace off) commands are used.
  /// - Supporting the execution of multiple statements on a single line, separated by colons (`:`).
  /// 
  /// This function is called repeatedly as the interpreter processes each line of input or code,
  /// ensuring that every command or statement is executed in the correct sequence.
  ///
  /// Example Usage:
  /// - The `docmd` function is invoked when a command needs to be processed, such as in the REPL loop in `Main`.
  /// 
  /// Error Handling:
  /// - If an unknown token or an error is encountered during execution, the function sets `errors` to `true`
  ///   and exits to prevent further execution.
  ///
  /// Tracing:
  /// - If tracing is enabled (`tracing` is `true`), the function outputs detailed information about the current line
  ///   and token being processed, which is useful for debugging.
  /// 
  /// Program Flow:
  /// - The function manages program flow by continuing execution from the current line and moving to the next line or
  ///   token as needed, until the entire line is processed or an error occurs.
  /// </summary>
  static void docmd() {
    bool running = false;
    while (true) {
      // If tracing is enabled and the current token is not a colon, output trace information.
      if (tracing && tok[0] != ':') Console.WriteLine("[" + curline + "] " + tok + " " + thech + " " + thelin.Substring(textp - 1));

      // Determine the action based on the current token.
      switch (tok) {
        case "bye": case "quit": nexttok(); Environment.Exit(1); break;   // Exit the interpreter.
        case "end": case "stop": nexttok();          return;              // Stop execution.
        case "clear"       : nexttok(); clearvars(); return;              // Clear all variables.
        case "help"        : nexttok(); help();      return;              // Display help information.
        case "list"        : nexttok(); liststmt();  return;              // List all program lines.
        case "load"        : nexttok(); loadstmt();  return;              // Load a program from a file.
        case "new"         : nexttok(); newstmt();   return;              // Clear the current program (start new).
        case "run"         : nexttok(); runstmt(); running = true; break; // Run the program.
        case "save"        : nexttok(); savestmt();  return;              // Save the current program to a file.
        case "tron"        : nexttok(); tracing = true; break;            // Enable tracing.
        case "troff"       : nexttok(); tracing = false; break;           // Disable tracing.
        case "cls"         : nexttok(); Console.Clear(); break;           // Clear the console screen.
        case "for"         : nexttok(); forstmt();   break;               // Execute a FOR loop.
        case "gosub"       : nexttok(); gosubstmt(); break;               // Call a subroutine.
        case "goto"        : nexttok(); gotostmt();  break;               // Jump to a specific line number.
        case "if"          : nexttok(); ifstmt();    break;               // Execute an IF conditional statement.
        case "input"       : nexttok(); inputstmt(); break;               // Get input from the user.
        case "next"        : nexttok(); nextstmt();  break;               // End a FOR loop iteration.
        case "print": case "?":nexttok(); printstmt(); break;             // Print output to the console.
        case "return"      : nexttok(); returnstmt();break;               // Return from a subroutine.
        case "@"           : nexttok(); arrassn();   break;               // Assign a value to an array element.
        case ":"           : nexttok();              break;               // Skip to the next statement in a multiple-statement line.
        case ""            :                         break;               // Do nothing (empty token).
        default:
          // Handle variable assignment.
          if (tok == "let") nexttok();  // Skip optional "let" keyword.
          if (toktype == "ident") {
            assign();     // Assign a value to a variable.
          } else {
            // Unknown token or command.
            Console.WriteLine("Unknown token " + tok + " at line " + curline); errors = true; // Flag an error.
          }
          break;
      }

      if (errors) return;                 // Exit if an error occurred.

      // If we reach the end of the program, or the next line is beyond the program limits, stop.
      if (curline + 1 >= pgm.Length) {
        showtime(running);                // Display the execution time if the program was running.
        return;
      }

      // Skip empty tokens (end of line, for example) and move to the next line if necessary.
      while (tok == "") {
        if (curline == 0 || curline + 1 >= pgm.Length) {
          showtime(running);              // Display execution time if needed.
          return;
        }
        initlex(curline + 1);             // Initialize the next line for processing.
      }
    }
  }

  /// <summary>
  /// Displays the elapsed time of the program execution if the program was running.
  /// 
  /// The `showtime` function calculates and displays the amount of time that has passed since
  /// the program started running. This function is called when the program execution is complete
  /// or when the interpreter needs to stop the running program. It provides a simple performance
  /// measurement by outputting the elapsed time in seconds.
  ///
  /// Key functionalities include:
  /// - Calculating the current time using `DateTime.UtcNow`.
  /// - Determining the difference in seconds between the current time and the start time (`timestart`).
  /// - Printing the elapsed time to the console, but only if the `running` flag is `true`, indicating that the program was actually running.
  /// 
  /// Parameters:
  /// - `running`: A boolean flag that indicates whether the program was running. If `true`, the elapsed time is displayed; if `false`, no output is made.
  ///
  /// Example Usage:
  /// - `showtime(true);` would display the elapsed time if the program was running.
  /// - `showtime(false);` would result in no output, as the program wasn't running or timing wasn't needed.
  /// 
  /// Practical Effects:
  /// - Provides feedback to the user on how long the program took to execute, which can be useful for performance monitoring or debugging.
  ///
  /// Note:
  /// - The function only outputs the time if the program was in a running state (`running` is `true`). This prevents unnecessary output when the program hasn't actually been executed.
  /// </summary>
  static void showtime(bool running) {
    TimeSpan timenow = (DateTime.UtcNow - new DateTime(1970, 1, 1));    // Get the current time as a TimeSpan.
    if (running)  // If the program was running, calculate and display the elapsed time.
      Console.WriteLine("Took : " + (timenow.TotalSeconds - timestart.TotalSeconds) + " seconds");
  }

  /// <summary>
  /// Displays a help menu listing all available commands and syntax for the TinyBasic interpreter.
  /// This function provides users with guidance on how to use the interpreter, 
  /// including the available commands, operators, and syntax for defining variables, 
  /// control structures, and other basic operations.
  /// </summary>
  static void help() {
    Console.WriteLine("+---------------------- Tiny Basic Help (C#)--------------------------+" );
    Console.WriteLine("| bye, clear, end, help, list, load, new, run, save, stop             |");
    Console.WriteLine("| goto <expr>                                                         |");
    Console.WriteLine("| gosub <expr> ... return                                             |");
    Console.WriteLine("| if <expr> then <statement>                                          |");
    Console.WriteLine("| input [prompt,] <var>                                               |");
    Console.WriteLine("| <var>=<expr>                                                        |");
    Console.WriteLine("| print <expr|string>[,<expr|string>][;]                              |");
    Console.WriteLine("| rem <anystring>                                                     |");
    Console.WriteLine("| Operators: + - * / < <= > >= <> =                                   |");
    Console.WriteLine("| Integer variables a..z, and array @(expr)                           |");
    Console.WriteLine("| Functions: rnd(expr)                                                |");
    Console.WriteLine("+---------------------- Tiny Basic Help ------------------------------+" );
  }

  /// <summary>
  /// Executes a `GOSUB` statement, saving the current execution state and jumping to a subroutine.
  /// 
  /// The `gosubstmt` function handles the `GOSUB` command in the TinyBasic interpreter. This command is used
  /// to call a subroutine at a specific line number in the program. When a `GOSUB` statement is encountered,
  /// the function saves the current line number and position within the line (the state of the interpreter) 
  /// onto stacks (`gstackln` and `gstacktp`), allowing the interpreter to return to this exact point when the 
  /// subroutine is finished and a `RETURN` statement is executed.
  ///
  /// Key functionalities include:
  /// - Pushing the current line number (`curline`) onto the `gstackln` stack.
  /// - Pushing the current position within the line (`textp`) onto the `gstacktp` stack.
  /// - Calling the `gotostmt()` function to jump to the line number specified in the `GOSUB` statement, where the subroutine begins.
  ///
  /// Example Usage:
  /// - `gosubstmt();` is called when the interpreter encounters a `GOSUB` command in the TinyBasic code.
  ///
  /// Practical Effects:
  /// - Allows for the execution of a subroutine while preserving the point in the program where the `GOSUB` was called.
  /// - The interpreter can later return to this saved point after executing a `RETURN` statement, resuming the program's flow from where it left off.
  ///
  /// Flow:
  /// - `GOSUB` saves the current state, jumps to the subroutine, and execution continues from the new line.
  /// - When `RETURN` is called in the subroutine, the interpreter retrieves the saved state and resumes execution at the saved point.
  ///
  /// Note:
  /// - This function works in tandem with the `returnstmt()` function, which handles returning from a subroutine.
  /// </summary>
  static void gosubstmt() {   // for gosub: save the line and column
    gstackln.Push(curline);   // Save the current line number on the stack.
    gstacktp.Push(textp);     // Save the current position in the line on the stack.

    gotostmt();               // Jump to the specified line number for the subroutine.
  }

  /// <summary>
  /// Handles variable assignment in the TinyBasic interpreter.
  /// 
  /// The `assign` function processes an assignment statement where a value is assigned to a variable.
  /// This function is invoked when the interpreter encounters a statement like `LET A = 10` or `A = 10`.
  /// It identifies the target variable, evaluates the expression on the right-hand side, and stores the result
  /// in the appropriate variable storage. If tracing is enabled, it also outputs the assignment operation for debugging purposes.
  ///
  /// Key functionalities include:
  /// - Identifying the target variable using the `getvarindex()` function, which converts the variable name into an index.
  /// - Parsing and ensuring the presence of the assignment operator (`=`).
  /// - Evaluating the expression on the right-hand side of the assignment using the `expression()` function.
  /// - Storing the evaluated result in the corresponding position in the `vars[]` array, where variables `a` through `z` are stored.
  /// - Optionally, if tracing is enabled (`tracing` is `true`), outputting the assignment operation to the console for debugging.
  ///
  /// Example Usage:
  /// - `assign();` is called when the interpreter encounters a statement like `LET A = 10` or `A = B + 5`.
  ///
  /// Practical Effects:
  /// - Ensures that variables are correctly assigned values during program execution, enabling the program to maintain and update state as it runs.
  /// - Provides feedback on variable assignments if tracing is enabled, helping with debugging and understanding program flow.
  ///
  /// Note:
  /// - The function assumes that the current token (`tok`) is the variable being assigned and expects an `=` to follow.
  /// - The `expression()` function handles any complexity in the right-hand side expression, including arithmetic operations, function calls, and variable references.
  /// </summary>
  static void assign() {
    int var;
    var = getvarindex();          // Get the index of the variable being assigned (e.g., 'a' -> 0, 'b' -> 1, etc.).
    nexttok();      // Move to the next token, which should be the '=' sign.
    expect("=");    // Ensure that the '=' sign is present.
    vars[var] = expression(0);    // Evaluate the expression on the right-hand side and assign the result to the variable.
    if (tracing) Console.WriteLine("*** " + (char)(var + 'a') + " = " + vars[var]);   // If tracing is enabled, print the assignment operation for debugging.
  }

  /// <summary>
  /// Handles the assignment of values to elements in the `@` array in the TinyBasic interpreter.
  /// 
  /// The `arrassn` function is responsible for processing assignments to the special `@` array in TinyBasic. 
  /// This array allows indexed access to multiple values, and the `arrassn` function handles the assignment 
  /// of a value to a specific index within this array. The function evaluates the index and the expression 
  /// on the right-hand side of the assignment, then stores the result in the appropriate position in the `atarry` array.
  /// 
  /// Key functionalities include:
  /// - Evaluating the expression inside the parentheses to determine the index in the `@` array where the value should be stored.
  /// - Ensuring that the `=` operator is present to signify assignment.
  /// - Evaluating the expression on the right-hand side of the `=` and assigning the result to the specified index in the `atarry` array.
  /// - Optionally, if tracing is enabled (`tracing` is `true`), outputting the array assignment operation to the console for debugging.
  /// 
  /// Example Usage:
  /// - `arrassn();` is called when the interpreter encounters a statement like `@(5) = 10`.
  ///
  /// Practical Effects:
  /// - Allows the TinyBasic program to store and manipulate multiple values in the `@` array using indexed access, 
  ///   providing a way to handle more complex data structures than simple variables.
  /// 
  /// Note:
  /// - The function assumes that the current token is the `@` symbol and expects an index expression in parentheses, 
  ///   followed by an `=` and a value expression.
  /// - The `expression()` function is used to handle both the index and the value, allowing for dynamic and calculated assignments.
  /// </summary>
  static void arrassn() {   // array assignment: @(expr) = expr
    int n, atndx;

    atndx = parenexpr();        // Evaluate the expression within parentheses to determine the array index.
    if (tok != "=") {
      Console.WriteLine("Array Assign: Expecting '=', found: " + tok);    // Error if '=' is not found.
      errors = true;
    } else {
      nexttok();                // Skip the '=' sign.
      n = expression(0);        // Evaluate the expression on the right-hand side of the assignment.
      atarry[atndx] = n;        // Assign the evaluated value to the specified index in the `atarry` array.
      if (tracing)              // If tracing is enabled, print the assignment operation for debugging.
        Console.WriteLine("*** @(" + atndx + ") = " + n);
    }
  }

  /// <summary>
  /// Handles the `FOR` loop initialization in the TinyBasic interpreter.
  /// 
  /// The `forstmt` function is responsible for processing the initialization of a `FOR` loop in TinyBasic. 
  /// A `FOR` loop allows the program to repeatedly execute a block of code a specified number of times. 
  /// This function initializes the loop by setting up the loop variable, determining the loop's limit, and storing 
  /// the necessary information (such as the starting line, loop limit, and current position) to manage the loop's execution.
  /// 
  /// Key functionalities include:
  /// - Identifying the loop variable and assigning it an initial value by evaluating the expression after the `=` sign.
  /// - Parsing the `TO` keyword and evaluating the expression that defines the loop's limit.
  /// - Storing the loop variable, its limit, the current line number, and position in the `forvar`, `forlimit`, `forline`, and `forpos` arrays, respectively.
  /// - Ensuring that the interpreter can properly jump back to the start of the loop when the `NEXT` statement is encountered, using the stored information.
  /// 
  /// Example Usage:
  /// - `forstmt();` is called when the interpreter encounters a `FOR` statement, such as `FOR I = 1 TO 10`.
  ///
  /// Practical Effects:
  /// - Enables the execution of loop structures in TinyBasic, allowing repetitive tasks to be automated within the program.
  /// - Correctly manages the loop's state, ensuring that the interpreter can handle loop iterations and exit the loop when the condition is met.
  /// 
  /// Note:
  /// - The function assumes that the current token is the variable being used in the `FOR` loop and that it will be followed by `=` and `TO`.
  /// - It works in tandem with the `nextstmt()` function, which handles the continuation and termination of the loop when `NEXT` is encountered.
  /// - If the `TO` keyword is not found, the function flags an error, as the loop's limit is required for proper execution.
  /// </summary>
  static void forstmt() { // for i = expr to expr
    int var, forndx, n;

    var = getvarindex();          // Get the index of the loop variable (e.g., 'I' -> 8 if 'I' is the 9th letter of the alphabet).
    assign();                     // Assign the initial value to the loop variable (e.g., `I = 1`).
    // vars(var) has the value; var has the number value of the variable in 0..25
    forndx = var;                 // Store the loop variable's index for future reference.
    forvar[forndx] = vars[var];   // Store the initial value of the loop variable.
    if (tok != "to") {
      Console.WriteLine("For: Expecting 'to', found:" + tok); errors = true;    // Error if 'TO' is not found.
    } else {
      nexttok();                  // Move to the next token, which should be the loop limit.
      n = expression(0);          // Evaluate the expression that defines the loop's limit.
      forlimit[forndx] = n;       // Store the loop's limit.
      // need to store iter, limit, line, and col
      forline[forndx] = curline;  // Store the current line and position to manage where the loop starts and how to return to it.
      if (tok == "")
        forpos[forndx] = textp;   // If at the end of the line, store the current position.
      else
        forpos[forndx] = textp - 2;   // If not, adjust the position slightly to account for tokens.
      //forpos[forndx] textp; if (tok != "") forpos[forndx] -=2;
    }
  }

  /// <summary>
  /// Handles the `IF` statement in the TinyBasic interpreter, enabling conditional execution of code.
  /// 
  /// The `ifstmt` function processes the `IF` statement, which is used to conditionally execute other statements 
  /// based on the result of a logical or arithmetic expression. If the evaluated expression is true (non-zero), 
  /// the statement following the `IF` (and optionally `THEN`) is executed. If the expression is false (zero), 
  /// the interpreter skips the rest of the line or the conditional statement.
  /// 
  /// Key functionalities include:
  /// - Evaluating the condition expression following the `IF` keyword.
  /// - If the expression evaluates to true (non-zero), continuing to process the statement that follows the `IF` statement.
  /// - If the expression evaluates to false (zero), skipping to the end of the line or the next statement, effectively ignoring the subsequent code.
  /// - Optionally handling the `THEN` keyword, which is sometimes used in TinyBasic to separate the condition from the statement to be executed.
  /// - Supporting line branching with `GOTO` if the condition is met and a line number is provided after the `THEN` keyword.
  /// 
  /// Example Usage:
  /// - `ifstmt();` is called when the interpreter encounters an `IF` statement, such as `IF A > 10 THEN PRINT "A is large"`.
  ///
  /// Practical Effects:
  /// - Enables conditional logic in TinyBasic programs, allowing the execution of specific code blocks only when certain conditions are met.
  /// - Facilitates simple decision-making processes within a TinyBasic program, controlling the flow of execution based on variable states or calculations.
  /// 
  /// Note:
  /// - The function assumes that the current token is the `IF` keyword and expects an expression to follow.
  /// - It works by evaluating the expression and either executing the following statement or skipping it based on the result.
  /// - The function supports both inline conditional statements and branching to a different line using `GOTO`.
  /// </summary>
  static void ifstmt() {
    if (expression(0) == 0) {         // Evaluate the expression after the `IF` keyword
      skiptoeol();                    // If the expression is false (0), skip to the end of the line or the next statement.
      return;
    }
    if (tok == "then")                // Optionally handle the `THEN` keyword (it can be omitted).
      nexttok();                      // Move to the next token after `THEN`.
    if (toktype == "number")          // If the next token is a number, treat it as a line number and perform a `GOTO`.
      gotostmt();                     // Jump to the specified line number.
  }

  /// <summary>
  /// Handles the `INPUT` statement in the TinyBasic interpreter, prompting the user for input and storing it in a variable.
  /// 
  /// The `inputstmt` function processes the `INPUT` command, which is used to prompt the user to enter a value 
  /// during the execution of a TinyBasic program. The function reads the user input from the console, converts it 
  /// into an integer (or its ASCII equivalent if the input is non-numeric), and assigns it to a specified variable.
  /// 
  /// Key functionalities include:
  /// - Optionally displaying a prompt string before requesting input, if a string is specified in the `INPUT` statement.
  /// - Reading the input from the user and handling both numeric and non-numeric input appropriately.
  /// - Converting numeric input to an integer value and assigning it to the specified variable.
  /// - Converting non-numeric (character) input to its ASCII value and storing it in the specified variable.
  /// 
  /// Example Usage:
  /// - `inputstmt();` is called when the interpreter encounters an `INPUT` statement, such as `INPUT "Enter value:", A`.
  ///
  /// Practical Effects:
  /// - Enables TinyBasic programs to interact with the user, allowing them to provide input that can influence the program's behavior.
  /// - Facilitates dynamic program behavior based on user-provided data, enhancing the interactivity of TinyBasic programs.
  /// 
  /// Note:
  /// - The function assumes that the current token is the `INPUT` keyword and processes the following tokens as a prompt string (optional) and variable name.
  /// - The variable receiving the input must be a single-letter variable (e.g., `A` to `Z`).
  /// - If the user does not enter a value (i.e., presses enter without typing anything), the function defaults to storing `0` in the variable.
  /// </summary>
  static void inputstmt() {   // "input" [string ","] var
    int var;
    string st;
    // Check if the next token is a string (prompt), and if so, display it.
    if (toktype == "string") {
      Console.Write(tok.Substring(1));          // Display the prompt string without the leading quote.
      nexttok();                                // Move to the next token after the prompt string.
      expect(",");                              // Expect a comma after the prompt string.
    } else {
      Console.Write("? ");                      // If no prompt string is provided, display a default prompt.
    }
    var = getvarindex();                        // Identify the variable where the input should be stored.
    nexttok();                                  // Move to the next token (should be the variable to store input).
    st = Console.ReadLine();                    // Read the input from the user.
    if (st == "") st = "0";                     // If the input is empty, default to "0".
    if (Char.IsDigit(st[0])) {                  // Check if the input is numeric.
      vars[var] = Int32.Parse(st);              // Convert the input to an integer and store it in the variable.
    } else {
      // If the input is not numeric, store the ASCII value of the first character.
      vars[var] = (int)(st[0]); // turn characters into their ascii value
    }
  }

  /// <summary>
  /// Handles the `LIST` statement in the TinyBasic interpreter, displaying all stored program lines.
  /// 
  /// The `liststmt` function is responsible for processing the `LIST` command, which is used to output the entire 
  /// TinyBasic program currently stored in memory to the console. This function iterates through all possible line numbers, 
  /// checking if there is a corresponding line of code stored at each index. If a line is found, it prints the line number 
  /// followed by the code. This allows the user to review or debug the program they have entered.
  /// 
  /// Key functionalities include:
  /// - Iterating through the `pgm[]` array, which stores the program lines, and printing each non-empty line to the console.
  /// - Displaying each line with its corresponding line number, maintaining the order of the program as it was entered.
  /// 
  /// Example Usage:
  /// - `liststmt();` is called when the interpreter encounters a `LIST` command, displaying the entire program on the console.
  /// 
  /// Practical Effects:
  /// - Provides a way for users to see the entire TinyBasic program they have entered, helping with debugging, reviewing, and editing the program.
  /// - Outputs the program in a readable format, with line numbers, so users can easily identify specific parts of the code.
  /// 
  /// Note:
  /// - The function assumes that the program is stored in the `pgm[]` array, with line numbers as indices. Lines that do not exist (i.e., are empty) are skipped in the output.
  /// - After listing all the lines, the function prints a blank line for separation, providing a clear end to the listing output.
  /// </summary>
  static void liststmt() {
    int i;
    for (i = 1; i < pgm.Length; i++) {                        // Iterate through all possible line numbers.
      if (pgm[i] != "")                                       // Check if a line of code exists at this index.
        Console.WriteLine(i + " " + pgm[i]);                  // Print the line number followed by the code.
    }
    Console.WriteLine("");                                    // Print a blank line after listing all the lines.
  }

  /// <summary>
  /// Handles the `LOAD` statement in the TinyBasic interpreter, loading a program from a file into memory.
  /// 
  /// The `loadstmt` function processes the `LOAD` command, which allows the user to load a TinyBasic program 
  /// from a specified file into the interpreter's memory. The function reads each line from the file, parses it, 
  /// and stores it in the `pgm[]` array, associating each line with its corresponding line number in the program.
  /// This allows the user to resume working on or executing a previously saved TinyBasic program.
  /// 
  /// Key functionalities include:
  /// - Prompting the user for the filename if not provided directly in the command.
  /// - Opening the specified file and reading its contents line by line.
  /// - Parsing each line to extract the line number and the corresponding code, storing them in the `pgm[]` array.
  /// - Handling line numbers correctly, ensuring that the program structure is maintained as it was saved.
  /// - Resetting the program state before loading to ensure that no previous program data remains in memory.
  /// 
  /// Example Usage:
  /// - `loadstmt();` is called when the interpreter encounters a `LOAD` command, loading a program from a file specified by the user.
  /// 
  /// Practical Effects:
  /// - Enables the user to load and work with previously saved TinyBasic programs, facilitating the continuation of programming sessions across different times.
  /// - Ensures that the loaded program is structured correctly in memory, ready for editing or execution.
  /// 
  /// Note:
  /// - The function expects the program file to follow the standard TinyBasic format, where each line begins with a line number followed by the code.
  /// - If the specified file does not exist or cannot be read, the function should ideally handle the error gracefully, though this is not explicitly detailed in this implementation.
  /// </summary>
  static void loadstmt() {
    int n;
    string filename;
    StreamReader f;

    newstmt();                                                      // Clear the current program from memory before loading the new one.
    filename = getfilename("Load");                                 // Prompt the user for the filename if not provided.
    if (filename == "") return;                                     // If no filename is provided, exit the function.

    f = new StreamReader(filename);                                 // Open the specified file for reading.
    n = 0;
    while (f.Peek() > 0) {                                          // Continue reading until the end of the file.
      pgm[0] = f.ReadLine();                                        // Read the next line from the file.
      initlex(0);                                                   // Initialize the lexer to process the line.
      if (toktype == "number" && num > 0 && num <= pgm.Length) {    // If the line starts with a number, use it as the line number.
        pgm[num] = pgm[0].Substring(textp - 1);                     // Store the line in the appropriate index based on the line number.
        n = num;
      } else {
        // If no valid line number is found, treat it as a continuation of the previous line.
        n++;
        pgm[n] = pgm[0];
      }
    }
    f.Close();                                                      // Close the file after reading all lines.
    curline = 0;                                                    // Reset the current line pointer.
  }

  /// <summary>
  /// Clears the current program by resetting all program lines and variables.
  /// This function is typically called when a new program is started, ensuring that
  /// any previously entered program or variable values are removed.
  /// </summary>
  static void newstmt() {
    int i;
    clearvars();                          // Reset all variables to their initial state

    // Clear each line of the program
    for (i = 1; i < pgm.Length; i++) {
      pgm[i] = "";
    }
  }

  /// <summary>
  /// Handles the `NEXT` statement in the TinyBasic interpreter, managing the iteration of a `FOR` loop.
  /// 
  /// The `nextstmt` function processes the `NEXT` command, which is used to indicate the end of a `FOR` loop iteration. 
  /// This function increments the loop variable, checks if the loop should continue or exit, and either jumps back to the 
  /// beginning of the loop or proceeds to the next statement. It uses the information stored during the `FOR` statement 
  /// initialization to manage the loop correctly, including the loop variable, the loop limit, and the position to jump back to.
  /// 
  /// Key functionalities include:
  /// - Identifying the loop variable being iterated by checking the current token.
  /// - Incrementing the value of the loop variable and updating it in the `vars[]` array.
  /// - Comparing the updated loop variable value with the loop limit to determine if the loop should continue or terminate.
  /// - If the loop should continue, resetting the current line and position to the start of the loop block using the stored information.
  /// - If the loop has completed, advancing to the next statement after the `NEXT` command.
  /// 
  /// Example Usage:
  /// - `nextstmt();` is called when the interpreter encounters a `NEXT` statement, such as `NEXT I`.
  ///
  /// Practical Effects:
  /// - Manages loop iteration, allowing repetitive execution of a code block while the loop condition remains true.
  /// - Ensures that the loop variable is updated correctly and that the loop exits when the specified limit is reached.
  /// 
  /// Note:
  /// - The function works in tandem with the `forstmt()` function, which sets up the loop by storing the initial values, limits, and positions.
  /// - If the loop variable reaches or exceeds the loop limit, the function allows the interpreter to exit the loop and continue with the next part of the program.
  /// </summary>
  static void nextstmt() {
    int forndx;

    // tok needs to have the variable
    forndx = getvarindex();                                                             // Identify the loop variable from the current token.
    forvar[forndx] = forvar[forndx] + 1;                                                // Increment the loop variable and update its value.
    vars[forndx] = forvar[forndx];
    if (tracing) Console.WriteLine("*** " + (forndx + 'a') + " = " + vars[forndx]);     // If tracing is enabled, print the updated loop variable for debugging.
    if (forvar[forndx] <= forlimit[forndx]) {                                           // Check if the loop should continue or exit
      // If the loop should continue, reset the current line and position to the start of the loop.
      curline = forline[forndx];
      textp   = forpos[forndx];
      //print "nextstmt tok>"; tok; " textp>"; textp; " >"; mid$(thelin, textp)
      initlex2();                                                                       // Reinitialize the lexer to continue processing from the start of the loop.
    } else {
      nexttok(); //' skip the ident for now                                             // If the loop is done, move to the next statement after `NEXT`.
    }
  }

  /// <summary>
  /// Handles the `PRINT` statement in the TinyBasic interpreter, outputting expressions or strings to the console.
  /// 
  /// The `printstmt` function processes the `PRINT` command (or its shorthand `?`) in TinyBasic. This function is responsible for 
  /// evaluating and displaying expressions, variables, or literal strings on the console. It supports multiple expressions or 
  /// strings separated by commas or semicolons and manages formatting accordingly, including the option to suppress the newline 
  /// after the print operation based on the presence of a trailing semicolon.
  /// 
  /// Key functionalities include:
  /// - Iteratively evaluating and printing each expression or string in the `PRINT` statement.
  /// - Handling different types of tokens, such as strings and expressions, and formatting them for output.
  /// - Managing the print width using the `#` notation, allowing fixed-width formatting.
  /// - Handling trailing commas or semicolons to determine whether to continue printing on the same line or move to the next line.
  /// - If no trailing semicolon or comma is found, a newline is automatically added after the output.
  /// 
  /// Example Usage:
  /// - `PRINT "Hello, World!"` outputs `Hello, World!` followed by a newline.
  /// - `PRINT "Value of A:", A;` outputs the value of `A` on the same line without a newline at the end.
  /// 
  /// Practical Effects:
  /// - Allows the interpreter to display output to the user, which is essential for interacting with the program, debugging, and viewing results.
  /// - Supports flexible formatting options, making it easy to control how the output is displayed on the console.
  /// 
  /// Note:
  /// - The function supports the shorthand `?` for `PRINT`, making it more concise to use in code.
  /// - The output behavior (whether a newline is added or not) is influenced by the presence of commas and semicolons in the `PRINT` statement.
  /// </summary>
  // "print" expr { "," expr }] [","] {":" stmt} eol
  // expr can also be a literal string
  static void printstmt() {
    int printwidth;
    string junk;
    bool printnl = true;              // Flag to determine whether to print a newline after the output.

    while (tok != ":" && tok != "") { // Continue processing until the end of the statement or line.
      printnl = true;                 // Assume a newline will be printed unless a comma or semicolon changes this.
      printwidth = 0;

      // Check if a print width is specified using the `#` notation (e.g., `PRINT #5, "Hello"`).
      if (accept("#")) {
        if (num <= 0) { Console.WriteLine("Expecting a print width, found:" + tok); return; }
        printwidth = num;             // Set the print width.
        nexttok();
        if (!accept(",")) { Console.WriteLine("Print: Expecting a ',', found:" + tok); return; }
      }

      // Handle string literals.
      if (toktype == "string") {
        junk = tok.Substring(1);          // Remove the starting double-quote from the string token.
        nexttok();
      } else {
        junk = expression(0).ToString();  // Evaluate the expression and convert it to a string for printing.
      }

      // Handle print width formatting.
      printwidth = printwidth - junk.Length;
      if (printwidth <= 0) {
        Console.Write(junk);      // Print the string or expression result as-is.
      } else {
        Console.Write(" ".PadRight(printwidth) + junk);   // Print with leading spaces for alignment.
      }

      // Check for trailing comma or semicolon to determine if a newline should be suppressed.
      if (accept(",") || accept(";")) {
        printnl = false;    // Suppress newline if a comma or semicolon is present.
      } else {
        break;              // No more tokens to process, so exit the loop.
      }
    }

    // Print a newline if required (i.e., if no trailing comma or semicolon was found).
    if (printnl) Console.WriteLine("");
  }

  /// <summary>
  /// Handles the `RETURN` statement in the TinyBasic interpreter, returning from a subroutine call.
  /// 
  /// The `returnstmt` function is responsible for implementing the `RETURN` command, which is used to return 
  /// from a subroutine that was previously called by a `GOSUB` statement. This function retrieves the saved 
  /// line number and position from the stacks (`gstackln` and `gstacktp`) where the program should resume execution 
  /// after returning from the subroutine. This allows the program to continue execution from the point immediately 
  /// following the original `GOSUB` call.
  /// 
  /// Key functionalities include:
  /// - Popping the last saved line number (`curline`) from the `gstackln` stack, which indicates where the program should return to.
  /// - Popping the last saved position within the line (`textp`) from the `gstacktp` stack, ensuring that execution resumes at the correct point within the line.
  /// - Calling `initlex2()` to reinitialize the lexer and continue processing tokens from the saved position.
  /// 
  /// Example Usage:
  /// - `returnstmt();` is called when the interpreter encounters a `RETURN` command in the TinyBasic code.
  /// 
  /// Practical Effects:
  /// - Allows the interpreter to correctly handle subroutine calls and returns, ensuring that the program flow resumes 
  ///   smoothly after a subroutine has completed.
  /// 
  /// Flow:
  /// - When a `GOSUB` statement is encountered, the program state is saved (current line and position).
  /// - Upon encountering a `RETURN` statement, the program state is restored, and execution continues from the saved point.
  ///
  /// Note:
  /// - This function works in tandem with the `gosubstmt()` function, which handles jumping to the subroutine and saving the state.
  /// - If there is no corresponding `GOSUB` (i.e., if the stacks are empty), this function may cause an error, as it would attempt 
  ///   to pop from an empty stack.
  /// </summary>
  static void returnstmt() {    // return from a subroutine
    curline = gstackln.Pop();   // Restore the line number to return to by popping from the stack.
    textp   = gstacktp.Pop();   // Restore the position within the line by popping from the stack.
    initlex2();                 // Reinitialize the lexer to continue processing from the restored position.
  }

  /// <summary>
  /// Handles the `RUN` statement in the TinyBasic interpreter, starting the execution of the program from the first line.
  /// 
  /// The `runstmt` function initiates the execution of the TinyBasic program currently stored in memory. 
  /// It starts by resetting the interpreter's state, including clearing all variables and setting the current line to the beginning of the program. 
  /// The function then prepares the interpreter to begin executing the program from the first line of code, 
  /// or the lowest numbered line that contains code, continuing until the program ends or an error occurs.
  /// 
  /// Key functionalities include:
  /// - Resetting the program's state by clearing all variables using `clearvars()` to ensure a fresh start for the execution.
  /// - Recording the start time of the program execution to potentially measure the time taken to run the program (used by the `showtime` function).
  /// - Initializing the lexer to start processing the program from the first line of code by calling `initlex(1)`.
  /// - The program execution then proceeds under the control of the interpreter, starting with the first line and continuing through the rest of the program.
  /// 
  /// Example Usage:
  /// - `runstmt();` is called when the interpreter encounters a `RUN` command, starting the execution of the TinyBasic program.
  /// 
  /// Practical Effects:
  /// - Allows the user to execute the program they have written, starting from the first line of code and continuing sequentially.
  /// - Ensures that the program runs in a clean state by resetting all variables before execution begins.
  /// 
  /// Note:
  /// - The function assumes that the program is stored in the `pgm[]` array, with code beginning at line 1 or the first non-empty line.
  /// - The function does not handle program flow directly; it simply initiates the process, and the interpreter's main loop manages the execution from there.
  /// </summary>
  static void runstmt() {
    timestart = (DateTime.UtcNow - new DateTime(1970, 1, 1));     // Record the start time of the program execution.
    clearvars();                                                  // Reset all variables to ensure a fresh start for the program.
    initlex(1);                                                   // Initialize the lexer to start processing from the first line of the program.
  }

  /// <summary>
  /// Handles the `GOTO` statement in the TinyBasic interpreter, jumping to a specified line number in the program.
  /// 
  /// The `gotostmt` function processes the `GOTO` command, which is used to unconditionally jump to a specified 
  /// line number within the TinyBasic program. This function evaluates the expression following the `GOTO` keyword 
  /// to determine the target line number and then sets the interpreter's current line pointer to that line, 
  /// effectively redirecting the flow of execution to that part of the program.
  /// 
  /// Key functionalities include:
  /// - Evaluating the expression that follows the `GOTO` command to determine the target line number.
  /// - Validating that the target line number is within the acceptable range and corresponds to a valid line in the program.
  /// - Setting the interpreter's current line (`curline`) to the specified line number, enabling the program to continue execution from there.
  /// - Reinitializing the lexer using `initlex(num)` to start processing the new line.
  /// 
  /// Example Usage:
  /// - `gotostmt();` is called when the interpreter encounters a `GOTO` statement, such as `GOTO 100`.
  ///
  /// Practical Effects:
  /// - Allows the program to jump to a different part of the code, enabling non-linear control flow such as loops, conditionals, and error handling.
  /// - Provides a simple yet powerful mechanism for controlling the sequence of execution within a TinyBasic program.
  /// 
  /// Note:
  /// - The function assumes that the current token is the `GOTO` keyword, followed by a valid expression that evaluates to a line number.
  /// - If the specified line number is invalid (e.g., outside the range of defined lines), the function flags an error, preventing the jump.
  /// </summary>
  static void gotostmt() {
    num = expression(0);        // Evaluate the expression to determine the target line number.
    validlinenum();             // Validate that the line number is within the valid range and corresponds to an actual line.
    initlex(num);               // Reinitialize the lexer to start processing from the specified line number.
  }

  /// <summary>
  /// Handles the `SAVE` statement in the TinyBasic interpreter, saving the current program to a file.
  /// 
  /// The `savestmt` function processes the `SAVE` command, allowing the user to save the current TinyBasic program 
  /// stored in memory to a file. This function prompts the user for a filename (if not provided), then iterates through 
  /// all the lines of the program stored in the `pgm[]` array and writes each non-empty line to the specified file. 
  /// The saved file can later be loaded and executed, preserving the user's work for future sessions.
  /// 
  /// Key functionalities include:
  /// - Prompting the user for a filename if it is not provided as part of the `SAVE` command.
  /// - Opening the specified file for writing, overwriting any existing content.
  /// - Iterating through the `pgm[]` array, which stores the TinyBasic program, and writing each non-empty line to the file.
  /// - Writing the line number followed by the corresponding code to the file, maintaining the structure of the program.
  /// 
  /// Example Usage:
  /// - `savestmt();` is called when the interpreter encounters a `SAVE` command, saving the current program to a file specified by the user.
  /// 
  /// Practical Effects:
  /// - Allows users to save their work, enabling them to continue programming sessions later by loading the saved program.
  /// - Ensures that the program is stored in a format that can be easily reloaded and executed by the interpreter.
  /// 
  /// Note:
  /// - The function expects the filename to have a `.bas` extension, adding it if not provided by the user.
  /// - If the specified file cannot be opened for writing, the function should ideally handle the error, though this implementation assumes the operation will succeed.
  /// </summary>
  static void savestmt() {
    int i;
    string filename;
    StreamWriter f;

    filename = getfilename("Save");                     // Prompt the user for the filename if not provided.
    if (filename == "") return;                         // If no filename is provided, exit the function.
    f = new StreamWriter(filename, false);              // Open the specified file for writing, overwriting any existing content.
    for (i = 1; i < pgm.Length; i++) {                  // Iterate through all possible line numbers.
      if (pgm[i] != "")                                 // Check if a line of code exists at this index.
        f.WriteLine(i + " " + pgm[i]);                  // Write the line number followed by the code to the file.
    }
    f.Close();                                          // Close the file after writing all lines.
  }

  /// <summary>
  /// Prompts the user for a filename, returning the filename with a `.bas` extension if none is provided.
  /// 
  /// The `getfilename` function is used to obtain a filename from the user for saving or loading a TinyBasic program. 
  /// Depending on the context (such as `SAVE` or `LOAD` operations), this function either uses a filename provided as 
  /// part of the command or prompts the user to enter one. It ensures that the filename has a `.bas` extension, which 
  /// is standard for TinyBasic program files, adding the extension if the user does not provide it.
  /// 
  /// Key functionalities include:
  /// - Checking if the current token is a string (indicating that a filename was provided directly in the command).
  /// - If no filename is provided in the command, prompting the user to enter one interactively.
  /// - Ensuring that the filename ends with a `.bas` extension, adding it if necessary.
  /// - Returning the validated filename as a string.
  /// 
  /// Example Usage:
  /// - `getfilename("Save");` is called when the interpreter needs to prompt the user for a filename during a `SAVE` operation.
  /// 
  /// Practical Effects:
  /// - Ensures that files are saved and loaded with a consistent `.bas` extension, making it easier to manage and identify TinyBasic programs.
  /// - Provides a simple, interactive way for users to specify filenames, either directly in commands or through prompts.
  /// 
  /// Note:
  /// - The function assumes that if the filename is provided as part of the command, it is enclosed in quotes (e.g., `"program1"`).
  /// - If the user does not enter a filename when prompted, the function returns an empty string, signaling that the operation should be canceled or handled accordingly.
  /// </summary>
  /// <param name="action">A string indicating the context of the filename request, such as "Save" or "Load".</param>
  /// <returns>A string representing the validated filename, with a `.bas` extension if needed.</returns>
  static string getfilename(string action) {
    string filename;
    if (toktype == "string") {
      filename = tok.Substring(1);                        // Extract the filename from the token, removing the leading quote.
    } else {
      // If no filename is provided in the command, prompt the user to enter one.
      Console.Write(action + ": ");
      filename = Console.ReadLine();
    }
    if (filename == "") return "";                        // If the filename is empty, return an empty string.
    if (filename.IndexOf(".") == -1) filename += ".bas";  // Ensure the filename ends with ".bas". If not, add the extension.
    return filename;                                      // Return the validated filename.
  }

  /// <summary>
  /// Validates that the current line number is within the acceptable range for the TinyBasic program.
  /// 
  /// The `validlinenum` function checks whether the line number stored in the global variable `num` is within 
  /// the valid range of line numbers for the TinyBasic interpreter. This function ensures that the line number 
  /// is greater than 0 and less than the maximum allowed (`c_maxlines`), which is crucial for maintaining the integrity 
  /// of the program's structure. If the line number is outside this range, the function sets the error flag and provides 
  /// an error message, preventing further processing of the invalid line.
  /// 
  /// Key functionalities include:
  /// - Checking if the line number (`num`) is greater than 0 and less than the maximum allowable line number (`c_maxlines`).
  /// - Flagging an error and displaying an error message if the line number is out of range.
  /// 
  /// Example Usage:
  /// - `validlinenum();` is called when the interpreter needs to validate a line number, such as during line input or execution.
  /// 
  /// Practical Effects:
  /// - Ensures that all line numbers used in the TinyBasic program are within the allowable range, preventing errors related to invalid line numbers.
  /// - Helps maintain the program's structure by ensuring that line numbers are within the defined limits, which is essential for correct program flow and execution.
  /// 
  /// Note:
  /// - The function assumes that the line number to be validated is already stored in the global variable `num`.
  /// - If the line number is invalid, the function sets the `errors` flag to `true`, which signals the interpreter to handle the error appropriately.
  /// </summary>
  static void validlinenum() {
    if (num <= 0 || num >= pgm.Length) {
      Console.WriteLine("Line number out of range");    // Display an error message if the line number is invalid.
      errors = true;                                    // Set the error flag to prevent further processing of this line.
    }
  }

  /// <summary>
  /// Clears all variables and resets the state of the TinyBasic interpreter's variable storage.
  /// 
  /// The `clearvars` function is responsible for resetting the interpreter's variable state by clearing all 
  /// the variables used in the TinyBasic program. This includes setting all elements of the `vars[]` array, which 
  /// stores the values of variables `a` through `z`, to zero. Additionally, the function clears the stacks used 
  /// for managing `GOSUB`/`RETURN` calls, ensuring that no residual data from previous program runs can affect the 
  /// current execution. This function is typically called at the beginning of program execution or when the `CLEAR` 
  /// command is issued, ensuring a clean state for variables and subroutine management.
  /// 
  /// Key functionalities include:
  /// - Resetting all variable values in the `vars[]` array to zero, effectively clearing all integer variables `a` to `z`.
  /// - Clearing the `gstackln` and `gstacktp` stacks, which are used to store line numbers and text positions for `GOSUB`/`RETURN` operations.
  /// 
  /// Example Usage:
  /// - `clearvars();` is called when the interpreter needs to reset the state of variables and subroutine stacks, typically at the start of program execution or in response to a `CLEAR` command.
  /// 
  /// Practical Effects:
  /// - Ensures that the TinyBasic program starts with a clean slate, with no leftover variable values or subroutine states from previous runs.
  /// - Prevents unintended behavior caused by residual data in variables or stacks, promoting predictable and correct program execution.
  /// 
  /// Note:
  /// - This function does not clear the `atarry[]` array or other potential data structures; it specifically targets the basic variables and subroutine stacks.
  /// </summary>
  static void clearvars() {
    int i;
    // Reset all variable values in the vars[] array to zero.
    for(i = 0; i < c_maxvars; i++) {
      vars[i] = 0;
    }

    // Clear the stacks used for GOSUB/RETURN calls.
    gstackln.Clear();
    gstacktp.Clear();
  }

  /// <summary>
  /// Evaluates an expression enclosed in parentheses in the TinyBasic interpreter.
  /// 
  /// The `parenexpr` function is responsible for handling and evaluating expressions that are enclosed in 
  /// parentheses. This function ensures that the interpreter correctly processes the expression within the 
  /// parentheses by first checking for the opening `(`, then evaluating the enclosed expression, and finally 
  /// ensuring that it is properly closed with a `)`. This is crucial for maintaining the correct order of 
  /// operations, especially in more complex expressions where parentheses dictate the evaluation sequence.
  /// 
  /// Key functionalities include:
  /// - Checking for the presence of an opening parenthesis `(` before processing the expression.
  /// - Evaluating the expression within the parentheses using the `expression()` function.
  /// - Ensuring that the expression is properly closed with a closing parenthesis `)`, and flagging an error if not.
  /// - Returning the evaluated result of the expression within the parentheses.
  /// 
  /// Example Usage:
  /// - `parenexpr();` is called when the interpreter encounters an expression that begins with an opening parenthesis, such as `(a + b) * c`.
  ///
  /// Practical Effects:
  /// - Ensures that expressions within parentheses are correctly evaluated with appropriate precedence, allowing for accurate mathematical and logical operations in TinyBasic programs.
  /// - Prevents errors related to unmatched parentheses by checking for both the opening and closing parenthesis.
  /// 
  /// Note:
  /// - This function assumes that the current token is an opening parenthesis `(` and proceeds accordingly. If the expected parentheses are not found, the function flags an error.
  /// - The `expression()` function is called to handle the actual evaluation of the expression within the parentheses, ensuring that all operations are considered correctly.
  /// </summary>
  /// <returns>The integer result of the evaluated expression within the parentheses.</returns>
  static int parenexpr() {
    int n;

    expect("(");              // Ensure that the expression starts with an opening parenthesis `(`.
    if (errors) return 0;     // If there is an error (e.g., missing `(`), return 0.
    n = expression(0);        // Evaluate the expression inside the parentheses.
    expect(")");              // Ensure that the expression is closed with a closing parenthesis `)`.
    return n;                 // Return the result of the evaluated expression.
  }

  /// <summary>
  /// Evaluates and returns the value of an arithmetic or logical expression in the TinyBasic interpreter.
  /// 
  /// The `expression` function is a core part of the TinyBasic interpreter, responsible for parsing and evaluating
  /// expressions that may include variables, constants, arithmetic operators, logical operators, and function calls.
  /// This function uses a precedence-based parsing technique to ensure that operations are performed in the correct order.
  /// 
  /// Key functionalities include:
  /// - Handling unary operators (e.g., `-`, `+`) and numeric literals, variables, and function calls at the start of an expression.
  /// - Recursively parsing and evaluating sub-expressions with appropriate operator precedence, ensuring that expressions like
  ///   `a + b * 2` are evaluated correctly (i.e., multiplication before addition).
  /// - Supporting a variety of operators, including arithmetic (`+`, `-`, `*`, `/`, `mod`, `^`), logical (`and`, `or`), and relational
  ///   operators (`=`, `<>`, `<`, `<=`, `>`, `>=`).
  /// - Returning the final integer value of the evaluated expression.
  /// 
  /// Parameters:
  /// - `minprec`: An integer representing the minimum precedence level. This controls the order in which operators are processed,
  ///   ensuring that higher-precedence operations are evaluated before lower-precedence ones.
  /// 
  /// Example Usage:
  /// - `expression(0);` is typically called to evaluate an entire expression, starting with the lowest precedence level.
  /// 
  /// Practical Effects:
  /// - Allows the interpreter to correctly evaluate complex expressions involving multiple operators and operands, following
  ///   the correct mathematical and logical rules.
  /// 
  /// Note:
  /// - The function assumes that the current token (`tok`) is the beginning of an expression. It will consume tokens as it parses
  ///   and evaluate them according to their precedence until it completes the entire expression or encounters a token with lower precedence.
  /// - The function is recursive, meaning it may call itself to handle sub-expressions or operations that involve parentheses.
  /// </summary>
  /// <param name="minprec">The minimum precedence level to consider when evaluating the expression.</param>
  /// <returns>The evaluated integer result of the expression.</returns>
  static int expression(int minprec) {
    int n;

    // handle numeric operands - numbers and unary operators
    if (toktype == "number") { n = num; nexttok();
    } else if (tok == "-")   { nexttok(); n = -expression(7);   // Unary minus, with high precedence
    } else if (tok == "+")   { nexttok(); n =  expression(7);   // Unary plus, with high precedence
    } else if (tok == "not") { nexttok(); n = expression(3); if (n != 0) n = 1;   // Unary not, with medium precedence
    } else if (tok == "abs") { nexttok(); n = Math.Abs(parenexpr());    // Absolute value function
    } else if (tok == "asc") { nexttok(); expect("("); n = tok[1]; nexttok(); expect(")");    // ASCII value of character
    } else if (tok == "rnd" || tok == "irnd") { nexttok(); n = random.Next(1, parenexpr());   // Random number function
    } else if (tok == "sgn") { nexttok(); n = Math.Sign(parenexpr());     // Sign function
    } else if (toktype == "ident") { n = vars[getvarindex()]; nexttok();    // Variable value
    } else if (tok == "@") { nexttok(); n = atarry[parenexpr()];    // Array value
    } else if (tok == "(") { n =  parenexpr();    // Expression inside parentheses
    } else {
      Console.WriteLine("syntax error: expecting an operand, found: " + tok);
      errors = true;
      return 0;
    }

    while (true) { // while binary operator and precedence of tok >= minprec
      if (minprec <= 1 && tok == "or") { nexttok(); n = n | expression(2);
      } else if (minprec <= 2 && tok == "and") { nexttok(); n = n & expression(3);
      } else if (minprec <= 4 && tok == "=" )  { nexttok(); n = Convert.ToInt32(n == expression(5));
      } else if (minprec <= 4 && tok == "<" )  { nexttok(); n = Convert.ToInt32(n <  expression(5));
      } else if (minprec <= 4 && tok == ">" )  { nexttok(); n = Convert.ToInt32(n >  expression(5));
      } else if (minprec <= 4 && tok == "<>")  { nexttok(); n = Convert.ToInt32(n != expression(5));
      } else if (minprec <= 4 && tok == "<=")  { nexttok(); n = Convert.ToInt32(n <= expression(5));
      } else if (minprec <= 4 && tok == ">=")  { nexttok(); n = Convert.ToInt32(n >= expression(5));
      } else if (minprec <= 5 && tok == "+" )  { nexttok(); n = n + expression(6);
      } else if (minprec <= 5 && tok == "-" )  { nexttok(); n = n - expression(6);
      } else if (minprec <= 6 && tok == "*" )  { nexttok(); n = n * expression(7);
      } else if (minprec <= 6 && (tok == "/" || tok == "\\")) { nexttok(); n = n / expression(7);
      } else if (minprec <= 6 && tok == "mod") { nexttok(); n = n % expression(7);
      } else if (minprec <= 8 && tok == "^") { nexttok(); n = (int)Math.Pow(n, expression(9));    // Exponentiation
      } else { break; }   // No more operators with sufficient precedence
    }
    return n;   // Return the evaluated value
  }

  /// <summary>
  /// Retrieves the index corresponding to a variable name in the TinyBasic interpreter.
  /// 
  /// The `getvarindex` function is responsible for converting a variable name (represented by a single letter from `a` to `z`)
  /// into an index that corresponds to a position in the `vars[]` array, where the values of variables are stored. 
  /// This function ensures that the variable name provided in the code is valid and maps it to an appropriate index 
  /// in the range 0 to 25, where `a` corresponds to index 0, `b` to index 1, and so on.
  /// 
  /// Key functionalities include:
  /// - Checking that the current token (`tok`) is a valid variable name (an identifier represented by a single letter).
  /// - Converting the variable name into its corresponding index in the `vars[]` array by subtracting the ASCII value of `'a'` from the ASCII value of the variable.
  /// - Flagging an error if the token is not a valid variable name.
  /// 
  /// Example Usage:
  /// - `getvarindex();` is called whenever the interpreter needs to access or modify a variable, such as in an assignment or expression evaluation.
  /// 
  /// Practical Effects:
  /// - Ensures that variable names are correctly mapped to their corresponding storage locations in the `vars[]` array, enabling the interpreter to manage variable values accurately.
  /// - Provides a simple mechanism to handle TinyBasic's limited variable naming convention (single-letter variables from `a` to `z`).
  /// 
  /// Note:
  /// - This function assumes that the current token is supposed to be a valid variable name. If it is not, the function flags an error and returns 0, which may cause further issues if not handled.
  /// - The TinyBasic interpreter uses single-letter variable names only, so this function is crucial for variable handling in this specific context.
  /// </summary>
  /// <returns>The integer index corresponding to the variable name in the `vars[]` array, or 0 if an error occurs.</returns>
  static int getvarindex() {
    if (toktype != "ident") {
      Console.WriteLine("Not a variable:" + tok);       // Flag an error if the token is not a valid identifier.
      errors = true;                                    // Set the error flag to prevent further processing of this invalid token.
      return 0;                                         // Return 0 as a default value to handle the error gracefully.
    }
    return tok[0] - 'a';
  }

  /// <summary>
  /// Ensures that the next token in the input matches the expected string, and flags an error if it does not.
  /// 
  /// The `expect` function is responsible for verifying that the next token in the TinyBasic interpreter's input stream 
  /// matches a specific expected string (`s`). This function is commonly used to enforce syntax rules, ensuring that 
  /// certain keywords or symbols appear where they are required. If the expected token is not found, the function flags 
  /// an error and outputs an error message, which helps to catch and report syntax errors during program parsing.
  /// 
  /// Key functionalities include:
  /// - Checking if the current token (`tok`) matches the expected string (`s`).
  /// - If the token matches, the function proceeds normally; if not, it flags an error and provides a detailed error message.
  /// - The error message includes the expected token, the actual token found, and the current line number, aiding in debugging.
  /// 
  /// Example Usage:
  /// - `expect("=");` is called when the interpreter expects an assignment operator `=` to follow a variable in an assignment statement.
  /// 
  /// Practical Effects:
  /// - Ensures that the TinyBasic program adheres to the correct syntax by enforcing the presence of required tokens.
  /// - **Error Handling**: Catches and reports syntax errors when the actual token does not match the expected one, helping users identify and correct mistakes in their code.
  /// 
  /// Note:
  /// - This function is particularly important in enforcing the structure of statements and expressions, such as ensuring that an `=` follows a variable in an assignment or that a closing `)` matches an opening `(`.
  /// </summary>
  /// <param name="s">The expected token string that should be present in the input.</param>
  static void expect(string s) {
    if (accept(s)) return;            // If the current token matches the expected string, proceed normally.
    // If the token does not match the expected string, flag an error and provide a detailed message.
    Console.WriteLine("(" + curline + ") expecting " + s + " but found " + tok + " =>" + pgm[curline]);
    errors = true;                    // Set the error flag to indicate that a syntax error has occurred.
  }

  /// <summary>
  /// Checks if the current token matches the expected string and advances to the next token if it does.
  /// 
  /// The `accept` function is used to determine whether the current token (`tok`) in the TinyBasic interpreter's 
  /// input stream matches a specific expected string (`s`). If the token matches the expected string, the function 
  /// advances the token stream by calling `nexttok()` to move to the next token. This function is often used to 
  /// conditionally process tokens in the program, allowing the interpreter to proceed only if certain tokens are present.
  /// 
  /// Key functionalities include:
  /// - Comparing the current token (`tok`) with the expected string (`s`).
  /// - If the token matches the expected string, advancing the token stream by calling `nexttok()`.
  /// - Returning `true` if the token matches and `false` otherwise, enabling conditional processing based on the token match.
  /// 
  /// Example Usage:
  /// - `if (accept(",")) { ... }` is used to check if the current token is a comma, and if so, proceed with the next steps in parsing.
  /// 
  /// Practical Effects:
  /// - Allows the interpreter to handle optional or expected tokens gracefully, making the parsing process more flexible.
  /// - Enables conditional logic based on whether certain tokens are present, which is useful for parsing statements with optional elements.
  /// 
  /// Note:
  /// - This function is typically used in conjunction with other functions like `expect()` and `nexttok()` to manage the flow of token processing in the interpreter.
  /// - If the token does not match the expected string, the function simply returns `false` without advancing the token stream.
  /// </summary>
  /// <param name="s">The expected token string that should be present in the input.</param>
  /// <returns>Returns `true` if the current token matches the expected string, otherwise returns `false`.</returns>

  static bool accept(string s) {
    if (tok == s) {     // Check if the current token matches the expected string.
      nexttok();        // If it matches, advance to the next token.
      return true;      // Return true, indicating that the token was accepted.
    }
    return false;       // Return false if the token does not match, indicating it was not accepted.
  }

  /// <summary>
  /// Initializes the lexical analysis for a specific line of the program.
  /// 
  /// The `initlex` function sets up the environment necessary for tokenizing and parsing
  /// a line of TinyBasic code. It prepares the interpreter to start reading and processing
  /// tokens (the smallest units of meaning, like keywords, numbers, or operators) from the specified line.
  ///
  /// Key functionalities include:
  /// - Setting the current line to be processed (`curline`) to the line number provided by `n`.
  /// - Resetting the character position pointer (`textp`) to the beginning of the line.
  /// - Calling `initlex2()` to begin the process of reading the line and identifying the first token.
  /// 
  /// This function is typically called when the interpreter needs to begin processing a new line,
  /// either during the execution of a program or when a new line is entered by the user.
  /// 
  /// Parameters:
  /// - `n`: The line number (`curline`) that the interpreter should start processing.
  /// 
  /// Example Usage:
  /// - `initlex(10);` would prepare the interpreter to start analyzing the 10th line of the program.
  /// </summary>
  /// <param name="n">The line number to initialize lexical analysis for.</param>
  static void initlex(int n) {
    curline = n;    // Set the current line number to the specified line.
    textp = 1;      // Reset the text pointer to the start of the line.
    initlex2();     // Begin the lexical analysis of the line.
  }

  /// <summary>
  /// Continues the lexical analysis for the current line of the program.
  /// 
  /// The `initlex2` function is responsible for initializing the reading of the current line (`curline`)
  /// and setting up the first token to be processed. It prepares the interpreter to start identifying
  /// and processing tokens from the beginning of the line.
  ///
  /// Key functionalities include:
  /// - Setting `thelin` to the content of the current line in the program (`pgm[curline]`).
  /// - Initializing `thech` as a placeholder for the first character to be processed.
  /// - Calling `nexttok()` to retrieve and prepare the first token from the line for further analysis or execution.
  /// 
  /// This function is typically called after `initlex(int n)` when a new line needs to be tokenized.
  /// It acts as a continuation step in the lexical analysis process, making the line ready for token-by-token parsing.
  /// 
  /// Example Usage:
  /// - `initlex2();` is called within `initlex(int n)` to begin tokenizing the specified line.
  /// </summary>
  static void initlex2() {
    thelin = pgm[curline];      // Set the current line content to be analyzed.
    thech = " ";                // Initialize the current character to a space (preparation for tokenizing).
    nexttok();                  // Retrieve and prepare the first token from the line.
  }

  /// <summary>
  /// Skips the remaining characters in the current line, effectively moving to the end of the line.
  /// 
  /// The `skiptoeol` function is used to bypass the rest of the current line (`thelin`) by setting the token (`tok`)
  /// and token type (`toktype`) to empty strings and advancing the text position pointer (`textp`) past the end of the line.
  /// This is particularly useful for ignoring comments or when an early termination of line processing is required,
  /// such as after encountering a `REM` statement or a syntax error.
  ///
  /// Key functionalities include:
  /// - Setting `tok` and `toktype` to empty strings, indicating that no more tokens should be processed on this line.
  /// - Advancing the position pointer (`textp`) to one past the last character in the line, effectively marking the line as fully processed.
  ///
  /// Example Usage:
  /// - `skiptoeol();` is typically called when a comment is encountered or when the interpreter needs to ignore the rest of the line.
  /// - After a `REM` statement, or when an error occurs, this function ensures that the remaining text on the line is not processed further.
  /// 
  /// Practical Effects:
  /// - Ensures that any remaining characters on the line are not treated as valid tokens.
  /// - Moves the interpreter's focus to the next line of code (if any) during the next iteration of parsing.
  /// </summary>
  static void skiptoeol() {
    tok = "";                   // Clear the current token.
    toktype = "";               // Clear the token type.
    textp = thelin.Length + 1;  // Move the text pointer to beyond the end of the current line.
  }

  /// <summary>
  /// Advances to the next token in the current line of the program.
  /// 
  /// The `nexttok` function is a crucial part of the lexical analysis process. It reads through the
  /// characters of the current line (`thelin`) and identifies the next token, which is the smallest unit of
  /// meaning such as a keyword, number, variable, or operator. The function updates the global variables `tok`
  /// (the current token) and `toktype` (the type of the current token) to reflect the next token found.
  ///
  /// Key functionalities include:
  /// - Skipping over whitespace to find the start of the next token.
  /// - Identifying and categorizing tokens as identifiers, numbers, strings, or punctuation.
  /// - Handling special cases like comments (`REM` or `'`), strings (enclosed in double quotes), and operators.
  /// 
  /// This function is called repeatedly as the interpreter parses through a line of code, moving from one token to the next,
  /// until the entire line has been processed.
  ///
  /// Example Usage:
  /// - `nexttok();` is called to move to the next token after processing the current one.
  /// 
  /// Error Handling:
  /// - If an unexpected character or sequence is encountered, `errors` is set to `true`, and an appropriate message is printed.
  /// </summary>
  static void nexttok() {
    tok = ""; toktype = "";               // Reset the current token and its type.

    // Skip over any leading whitespace to find the next token.
    for (;;) {
      if (thech == "") return;            // End of line reached.
      if (thech[0] > ' ') break;          // Found a non-whitespace character.
      getch();                            // Move to the next character.
    }

    tok = thech;                          // Start building the token with the current character.
    if (Char.IsLetter(tok[0])) {
      readident();                        // Read and identify keywords or variable names.
      if (tok == "rem") skiptoeol();      // Skip to end of line if 'REM' comment is found.
    } else if (Char.IsDigit(tok[0])) {
      readint();                          // Read a number token.
    } else if (tok == "'") {
      skiptoeol();                        // Skip to end of line for single-quote comments.
    } else if (tok == "\"") {             // Double quote marks the start of a string.
      readstr();                          // Read the full string token.
    } else {
      // Handle punctuation and operators.
      if ("#()*+,-/:;<=>?@\\^".IndexOf(tok) >= 0) {
        toktype = "punct";
        getch();                          // Move to the next character.
        if (tok == "<" || tok == ">") {   // Handle compound operators like "<=" or ">="
          if (thech == "=" || thech == ">") {
            tok = tok + thech;
            getch();
          }
        }
      } else {
        Console.WriteLine("What?" + thech + thelin);    // Unexpected character sequence.
        getch();
        errors = true;        // Mark an error.
      }
    }
  }

  /// <summary>
  /// Reads a string literal from the input line, handling quoted text in the TinyBasic interpreter.
  /// 
  /// The `readstr` function is responsible for reading and processing string literals in TinyBasic. 
  /// When the interpreter encounters a double quote (`"`) in the input, this function reads all subsequent characters 
  /// until it finds the closing double quote, forming a complete string token. The string is stored with its surrounding 
  /// quotes intact, allowing the interpreter to differentiate between string literals and other tokens during further processing.
  /// 
  /// Key functionalities include:
  /// - Setting the token type (`toktype`) to `"string"` to indicate that the current token is a string literal.
  /// - Reading characters from the input line, starting immediately after the opening double quote, until the closing double quote is found.
  /// - Handling errors if the string is not properly terminated by a closing double quote, which would indicate a syntax error in the program.
  /// - Storing the full string (including quotes) in the `tok` variable, making it available for subsequent processing in the interpreter.
  /// 
  /// Example Usage:
  /// - `readstr();` is called when the interpreter detects the start of a string literal (indicated by a double quote) in the input line.
  /// 
  /// Practical Effects:
  /// - Allows the interpreter to correctly parse and handle string literals in TinyBasic programs, ensuring that they are treated as single, cohesive tokens.
  /// - Ensures that errors related to unclosed strings are caught and reported, helping to prevent unexpected behavior in the program.
  /// 
  /// Note:
  /// - The function assumes that it is called immediately after the opening double quote is detected, and it will read characters until the closing quote is found.
  /// - If the string is not properly terminated (e.g., the closing quote is missing), the function flags an error and prevents further processing of the incomplete string.
  /// </summary>
  // leave the " as the beginning of the string, so it won't get confused with other tokens
  // especially in the print routines
  static void readstr() {
    toktype = "string";       // Set the token type to "string" to indicate that a string literal is being processed.
    getch();                  // Move past the opening double quote to start reading the string content.
    while (thech != "\"") {   // while not a double quote
      if (thech == "") {      // If the end of the line is reached before finding the closing quote, it's an error.
        Console.WriteLine("String not terminated");   // Report the error.
        errors = true;        // Set the error flag to indicate a problem.
        return; 
      }
      tok = tok + thech;      // Add the current character to the string token.
      getch();                // Move past the closing double quote to complete the string token.
    }
    getch();
  }

  /// <summary>
  /// Reads an integer literal from the input line, handling numeric values in the TinyBasic interpreter.
  /// 
  /// The `readint` function is responsible for reading and processing integer literals in TinyBasic. 
  /// When the interpreter encounters a digit in the input, this function reads all subsequent numeric characters 
  /// to form a complete integer token. The resulting integer value is stored in the `num` variable, and the 
  /// token is identified as a number (`toktype` is set to `"number"`).
  /// 
  /// Key functionalities include:
  /// - Setting the token type (`toktype`) to `"number"` to indicate that a numeric value is being processed.
  /// - Reading consecutive digits from the input line to form the complete integer value.
  /// - Storing the resulting integer value in the `num` variable for use in subsequent expression evaluations or commands.
  /// 
  /// Example Usage:
  /// - `readint();` is called when the interpreter detects the start of a numeric literal in the input line.
  /// 
  /// Practical Effects:
  /// - Allows the interpreter to correctly parse and handle integer literals in TinyBasic programs, ensuring that numeric values are treated as single tokens.
  /// - Converts the string representation of the numeric token into an integer value, making it available for arithmetic operations and comparisons.
  /// 
  /// Note:
  /// - The function assumes that it is called when the current character (`thech`) is a digit, and it continues reading until non-numeric characters are encountered.
  /// - The function does not handle floating-point numbers or other non-integer numeric formats; it is specifically designed for integer literals.
  /// </summary>
  static void readint() {
    tok = "";                                       // Initialize the token string as empty.
    toktype = "number";                             // Set the token type to "number" to indicate that a numeric literal is being processed.
    while (thech != "" && Char.IsDigit(thech[0])) { // Continue reading characters as long as they are digits, forming the complete integer token.
      tok += thech;                                 // Add the current digit to the token string.
      getch();                                      // Move to the next character in the input line.
    }
    num = Int32.Parse(tok);                         // Convert the token string to an integer value and store it in the `num` variable.
  }

  /// <summary>
  /// Reads an identifier (variable name) from the input line in the TinyBasic interpreter.
  /// 
  /// The `readident` function is responsible for reading and processing identifiers in TinyBasic. 
  /// Identifiers in TinyBasic are typically variable names, which are single letters from `A` to `Z` (or `a` to `z`).
  /// This function reads consecutive alphabetic characters to form the complete identifier token, and it stores the 
  /// resulting identifier in the `tok` variable. The token type (`toktype`) is set to `"ident"` to indicate that 
  /// the token represents an identifier.
  /// 
  /// Key functionalities include:
  /// - Setting the token type (`toktype`) to `"ident"` to indicate that an identifier is being processed.
  /// - Reading consecutive alphabetic characters from the input line to form the complete identifier.
  /// - Converting all alphabetic characters to lowercase to maintain consistency, as TinyBasic typically treats variable names case-insensitively.
  /// - Storing the resulting identifier in the `tok` variable for use in subsequent commands or expressions.
  /// 
  /// Example Usage:
  /// - `readident();` is called when the interpreter detects the start of an identifier (a letter) in the input line.
  /// 
  /// Practical Effects:
  /// - Allows the interpreter to correctly parse and handle variable names in TinyBasic programs, ensuring that identifiers are treated as single tokens.
  /// - Supports the consistent handling of variable names by converting them to lowercase, enabling case-insensitive variable usage.
  /// 
  /// Note:
  /// - The function assumes that it is called when the current character (`thech`) is a letter, and it continues reading until non-alphabetic characters are encountered.
  /// - Identifiers in TinyBasic are typically single letters, but this function can handle longer sequences of alphabetic characters if necessary.
  /// </summary>
  static void readident() {
    tok = "";                                         // Initialize the token string as empty.
    toktype = "ident";                                // Set the token type to "ident" to indicate that an identifier is being processed.
    while (thech != "" && Char.IsLetter(thech[0])) {  // Continue reading characters as long as they are alphabetic, forming the complete identifier.
      tok = tok + thech.ToLower();                    // Add the current letter to the token string and convert to lowercase.
      getch();                                        // Move to the next character in the input line.
    }
  }

  /// <summary>
  /// Retrieves the next character from the current line being processed.
  /// 
  /// The `getch` function advances the character position pointer (`textp`) within the current line (`thelin`)
  /// and updates `thech` with the next character to be processed. This function is essential for tokenizing
  /// the input line, as it allows the interpreter to read through the line one character at a time.
  ///
  /// Key functionalities include:
  /// - Moving the position pointer `textp` to the next character in the line.
  /// - Updating `thech` with the new character or setting it to an empty string if the end of the line is reached.
  /// - Handling the end of the line by setting `thech` to an empty string, indicating no more characters to process.
  /// 
  /// This function is called repeatedly by the lexer to sequentially process each character in the line,
  /// enabling the identification and formation of tokens like keywords, numbers, operators, and more.
  ///
  /// Example Usage:
  /// - `getch();` is called within `nexttok()` and other lexer functions to move to the next character in the line.
  /// 
  /// Practical Effects:
  /// - Allows the interpreter to sequentially process each character in the input line, enabling the identification and formation of tokens like keywords, numbers, operators, and more.
  /// - Detects the end of the input line, ensuring that the interpreter knows when to stop reading characters.
  /// 
  /// Note:
  /// - The function assumes that `textp` is initialized to the starting position of the line and that it is called repeatedly to move through the line until all characters have been processed.
  /// - It is a fundamental part of the lexical analysis phase, enabling the interpreter to break down the input into meaningful tokens for further processing.
  /// </summary>
  static void getch() {  // Any more text on this line?
    // Check if the current position is beyond the end of the line.
    if (textp > thelin.Length) {
      thech = "";       // If at the end of the line, set `thech` to an empty string.
      return;           // Exit the function, as there are no more characters to process.
    }
    // Update `thech` with the next character from the line.
    thech = thelin[textp - 1].ToString();     // `textp` is 1-based, so subtract 1 to get the correct index.
    textp++;                                  // Move the position pointer to the next character.
  }

}
*/