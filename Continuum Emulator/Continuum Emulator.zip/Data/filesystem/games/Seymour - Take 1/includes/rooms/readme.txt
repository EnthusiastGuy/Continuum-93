Background layer procedural generation

Backgrounds are "cityscapes" consisting mainly in a combination of the following elements:

    - sky
    - clouds
    - sun
    - hills
    - mountains
    - city buildings
    - town buildings

A cityscape always has a sky. It can be exclusively formed of either of: hills, mountains, city buildings, town buildings. Or, it can combine those.
The method of combination can generate different forms of landscape over the increasing X coordinate. For example it can start with city buildings
gradually morphing to hills then mountains, and the mountains may have some town buildings across.

A cityscape should have a shift parameter that would allow further definition of the cityscape beyont the maximum width of 480 pixels.
This is required so if the player travels across several adjacent areas, the background would slightly shift to offer the illusion of realistic
depth.

A cityscape uses:
    - a start X parameter used to resolve the cityscape horizontal shifting;
    - (optional) a start Y parameter used to resolve the cityscape vertical shifting;
    - a seed (as a 32 bit integer number) used with the random number generator;
    - a definition of the elements to be rendered, in order, from left to right along with the length over X where that element is predominant.

The definition of the elements to be rendered per cityscape contains:
    - the element to be rendered;
    - start Y elevation;
    - end Y elevation;
    - the X distance;

The particular way, spread and density of how elements are rendered is procedurally generated, subject to trial and error, while implementing
some basic patterns.

Procedure:
    - given all elements
        - for the current element
            - access the proper method of procedural drawing, generate internal variables and draw all instances of elements;
        - when the current element max X distance has been reached, move to the next element.
        - if the screen edge has been reached, stop rendering.


Layering:
=========

- layer 0: far background + background tiles;
- layer 1: collision;
- layer 2: clouds;
- layer 3: character;
- layer 4: ?;
- layer 5: foreground tiles;
- layer 6: text bubbles;
- layer 7: UI;



Room tiles structure
    Room ID             (2 bytes)
        Tile ID         (2 bytes)
        Layer           (1 byte)
        x               (2 bytes)
        y               (2 bytes)
        rx              (1 byte)
        ry              (1 byte)
        flipH
        flipV


tileID          2 bytes
video page      1 byte
X               2 bytes
Y               2 bytes
effects         1 byte
tiledH          1 byte
tiledV          1 byte



DrawTileMapSprite:

tile map source address         3 bytes
tile map width                  2 bytes
sprite X                        2 bytes
sprite Y                        2 bytes
sprite width                    2 bytes
sprite height                   2 bytes
=== TILE ===
video page                      1 byte
video X                         2 bytes
video Y                         2 bytes
effects                         1 byte
tiledH?                         1 byte
tiledW?                         1 byte
