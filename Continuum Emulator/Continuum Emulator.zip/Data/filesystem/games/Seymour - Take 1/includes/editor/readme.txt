Map editor

- UI: current room, current layer, visible layers, selected tile(s), total tiles, tiles list
- Mouse enabled: selects tiles on current layer, moves them around
- Directional arrows: fine-move selected tile(s)
- Bring selected tile(s) to front, back, or gradually move in the stack
- Save data/load data


