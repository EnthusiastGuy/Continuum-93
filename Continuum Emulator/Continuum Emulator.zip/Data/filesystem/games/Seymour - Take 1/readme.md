Seymour Take One
======================
remake by Enthusiast Guy

A fan-made creative remake of the original short game initially available on Amiga/ZX Spectrum/Amstrad CPC developed by Big Red Software and Codemasters.
This remake is currently work in progress and is being developed for the Continuum 93 fantasy retro computer in native assembly language.
It retains the original credits, preserves any and all copyrights while is also aimed as a humble homage to Peter Ranson, Paul Ranson and Fred Williams for their brilliant work.

This specific fan-made remake will act as the initial step and basis for a separate adventure sequel set out for Seymour at a later time.

... to be continued