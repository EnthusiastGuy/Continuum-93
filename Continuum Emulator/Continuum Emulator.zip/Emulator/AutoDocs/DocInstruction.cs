﻿namespace Continuum_Emulator.Emulator.AutoDocs
{
    // Instruction for the documentation area of the autogenerative system
    public class DocInstruction
    {
        public string Operator;
        public string Description;
    }
}
