public static class SystemMessages
{
    public static readonly uint MSG_OK = 0x0000;

    public static readonly uint ERR_STACK_OVERFLOW = 0x0010;
    public static readonly uint ERR_STACK_UNDERFLOW = 0x0011;
}