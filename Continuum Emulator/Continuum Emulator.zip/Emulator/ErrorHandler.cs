﻿namespace Continuum_Emulator.Emulator
{
    public static class ErrorHandler
    {
        public static void ReportRuntimeError(string message)
        {
            // For now, just do nothing
        }
    }
}
