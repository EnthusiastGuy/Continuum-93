﻿namespace Continuum_Emulator.Emulator.Window
{
    public class WindowState
    {
        public int ClientWidth;
        public int ClientHeight;
        public int ClientX;
        public int ClientY;
    }
}
